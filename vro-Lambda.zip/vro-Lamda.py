#Import dependencies
import requests
from requests.auth import HTTPBasicAuth

#Enter Environment Variables wrapped in single quotes
user = 'username'
password = 'password'
vro_ip = '0.0.0.0'
workflowid = '080165de-90bc-406b-817d-c85637f47292'

#Lambda Functions below here:
def vro_handler(event,context):
	#disable warning for certificates that aren't trusted. Use at own risk
	requests.packages.urllib3.disable_warnings()

	#set REST Headers
	headers = {
    	'Accept': 'application/json',
    	'Content-Type': 'application/json',
	}

	#Set payload data
	data = '{"parameters":[]}'

	#Make REST Request
	requests.post('https://' + vro_ip +':443/vco/api/workflows/' + workflowid + '/executions', \
	auth=HTTPBasicAuth(user, password), verify=False, headers=headers, data=data)
	
